---
title: "First Version is out."
description: "First version v0.1.0 is out."
date: 2023-11-26T16:26:40+08:00
draft: false
noindex: false
featured: false
pinned: false
series:
  - Releases
categories:
tags:
images:
  - https://example-images.razonyang.com/hello.webp?width=1920&height=1280
authors:
  - HB
  - HugoMods
---

We're proud to announce the first version (`v0.1.0`) of [HB cards theme](https://github.com/hbstack/theme-cards) is available now.

Please checkout out the [docs](< relref "/docs" >) for installing the theme.
