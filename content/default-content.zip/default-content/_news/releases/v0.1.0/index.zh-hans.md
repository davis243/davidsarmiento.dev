---
title: "首个版本已发布"
description: "首个版本 v0.1.0 已发布"
date: 2023-11-26T16:26:40+08:00
draft: false
noindex: false
featured: false
pinned: false
series:
 - 发布
categories:
tags:
images:
  - https://example-images.razonyang.com/hello.webp?width=1920&height=1280
---

我们很荣幸地宣布，[HB卡片主题](https://github.com/hbstack/theme-cards) 的第一个版本（`v0.1.0`）现已发布。

请查看[文档](< relref "/docs" >)以安装该主题。
