---
title: Categories
menu:
  main:
    parent: blog
    params:
      icon:
        vendor: bs
        name: folder
        color: orange
      description: All of categories.
---
