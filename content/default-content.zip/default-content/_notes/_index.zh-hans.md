---
title: 笔记
type: docs
description: 使用文档布局的另一个数字花园。
menu:
  main:
    weight: 1
    params:
      icon:
        vendor: bs
        name: pencil-square
---
