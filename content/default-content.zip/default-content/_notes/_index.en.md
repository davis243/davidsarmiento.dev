---
title: Notes
type: docs
description: Yet another digital garden that using docs layout.
menu:
  main:
    weight: 1
    params:
      icon:
        vendor: bs
        name: pencil-square
---
