---
title: Docs
description: The example of docs layout.
menu:
  main:
    weight: 1
    params:
      icon:
        vendor: bs
        name: book
---
