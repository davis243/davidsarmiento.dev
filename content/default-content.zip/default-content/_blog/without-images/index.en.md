---
title: Example Post without Images
featured: true
date: 2022-09-10
series:
  - Examples
tags:
  - Images
---

A sample for showing how theme display posts those without images.
